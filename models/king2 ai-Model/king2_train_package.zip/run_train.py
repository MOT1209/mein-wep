#!/usr/bin/env python3
"""
KING2 AI - Colab Training Script
التشغيل التلقائي: ضع هذا الملف في Alking_AI_Train على Google Drive
سيتم تنفيذه تلقائياً بواسطة كولاب
"""

import os
import sys
import json
import time
import subprocess
from datetime import datetime

LOG_FILE = "training_logs.txt"
DRIVE_PATH = "/content/drive/MyDrive/Alking_AI_Train"
os.makedirs(DRIVE_PATH, exist_ok=True)

def log(msg):
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line)
    with open(os.path.join(DRIVE_PATH, LOG_FILE), "a", encoding="utf-8") as f:
        f.write(line + "\n")

def run_cmd(cmd, capture=True):
    log(f"RUN: {cmd}")
    result = subprocess.run(cmd, shell=True, capture_output=capture, text=True)
    if result.stdout:
        for line in result.stdout.strip().split("\n"):
            log(f"  {line}")
    if result.stderr:
        for line in result.stderr.strip().split("\n"):
            log(f"  ERR: {line}")
    return result

# =============================================
# 1. CHECK GPU
# =============================================
log("=" * 50)
log("KING2 AI TRAINING - STARTING")
log("=" * 50)

log("=== 1. GPU CHECK ===")
run_cmd("nvidia-smi")

import torch
log(f"PyTorch: {torch.__version__}")
log(f"CUDA available: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    log(f"GPU: {torch.cuda.get_device_name(0)}")
    log(f"VRAM: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")

# =============================================
# 2. INSTALL DEPENDENCIES
# =============================================
log("=== 2. INSTALLING DEPENDENCIES ===")

deps = [
    "pip install -qU torch --index-url https://download.pytorch.org/whl/cu121",
    "pip install -qU transformers datasets accelerate peft bitsandbytes trl",
    "pip install -qU --upgrade huggingface_hub",
    "pip install -qU unsloth",
    "pip install -qU wandb",
]

for dep in deps:
    run_cmd(dep)

# Clone LLaMA Factory for structured training
if not os.path.exists("/content/LLaMA-Factory"):
    run_cmd("git clone --depth 1 https://github.com/hiyouga/LLaMA-Factory.git /content/LLaMA-Factory")
    run_cmd("cd /content/LLaMA-Factory && pip install -e '.[torch,metrics]'")

# =============================================
# 3. LOAD TRAINING DATA
# =============================================
log("=== 3. LOADING TRAINING DATA ===")

# Load from Drive - supports both formats
data_path = os.path.join(DRIVE_PATH, "king2_training.json")
enhanced_path = os.path.join(DRIVE_PATH, "king2_enhanced.json")

if os.path.exists(data_path):
    with open(data_path, "r", encoding="utf-8") as f:
        training_data = json.load(f)
    log(f"Loaded {len(training_data)} training examples from king2_training.json")
elif os.path.exists(enhanced_path):
    with open(enhanced_path, "r", encoding="utf-8") as f:
        training_data = json.load(f)
    log(f"Loaded {len(training_data)} training examples from king2_enhanced.json")
else:
    log("WARNING: No training data found! Downloading from Hugging Face...")
    run_cmd("pip install -qU huggingface_hub")
    from huggingface_hub import snapshot_download
    snapshot_download(
        repo_id="AlkingAI/king2-training-data",
        local_dir=DRIVE_PATH,
        repo_type="dataset",
        ignore_patterns=["*.md"]
    )
    log("Downloaded training data from Hugging Face")
    with open(os.path.join(DRIVE_PATH, "king2_training.json"), "r", encoding="utf-8") as f:
        training_data = json.load(f)

# Ensure dataset_info.json exists
info_path = os.path.join(DRIVE_PATH, "dataset_info.json")
if not os.path.exists(info_path):
    info = {
        "king2_training": {
            "file_name": "king2_training.json",
            "formatting": "sharegpt",
            "columns": {"messages": "conversations"},
            "tags": {
                "role_tag": "from",
                "content_tag": "value",
                "user_tag": "human",
                "assistant_tag": "gpt",
                "system_tag": "system"
            }
        }
    }
    with open(info_path, "w", encoding="utf-8") as f:
        json.dump(info, f, ensure_ascii=False, indent=2)
    log("Created dataset_info.json")

# Copy data to LLaMA Factory
run_cmd(f"mkdir -p /content/LLaMA-Factory/data")
run_cmd(f"cp '{data_path}' /content/LLaMA-Factory/data/")
run_cmd(f"cp '{info_path}' /content/LLaMA-Factory/data/")

log(f"Training samples: {len(training_data)}")

# =============================================
# 4. CONFIGURE TRAINING
# =============================================
log("=== 4. CONFIGURING TRAINING ===")

# Options
MODEL_CHOICE = os.environ.get("KING2_MODEL", "qwen")  # qwen or gemma
if MODEL_CHOICE == "qwen":
    model_name = "Qwen/Qwen3.5-9B"
    template = "qwen"
    output_dir = "king2-qwen3.5-9b"
else:
    model_name = "google/gemma-4-e4b-it"
    template = "gemma"
    output_dir = "king2-gemma-4-e4b"

log(f"Model: {model_name}")
log(f"Template: {template}")
log(f"Output: {output_dir}")

import yaml
config = {
    "model_name_or_path": model_name,
    "template": template,
    "finetuning_type": "lora",
    "dataset": "king2_training",
    "dataset_dir": "data",
    "max_samples": int(os.environ.get("KING2_MAX_SAMPLES", "100000")),
    "cutoff_len": int(os.environ.get("KING2_CUTOFF_LEN", "2048")),
    "lora_rank": int(os.environ.get("KING2_LORA_RANK", "16")),
    "lora_alpha": int(os.environ.get("KING2_LORA_ALPHA", "32")),
    "lora_dropout": 0.1,
    "lora_target": "all",
    "quantization_bit": int(os.environ.get("KING2_QUANT_BIT", "4")),
    "quantization_method": "bitsandbytes",
    "per_device_train_batch_size": int(os.environ.get("KING2_BATCH", "1")),
    "gradient_accumulation_steps": int(os.environ.get("KING2_GRAD_ACC", "8")),
    "learning_rate": float(os.environ.get("KING2_LR", "2.0e-4")),
    "num_train_epochs": float(os.environ.get("KING2_EPOCHS", "3.0")),
    "max_grad_norm": 1.0,
    "warmup_ratio": 0.1,
    "logging_steps": int(os.environ.get("KING2_LOG_STEPS", "5")),
    "save_steps": int(os.environ.get("KING2_SAVE_STEPS", "100")),
    "save_total_limit": 2,
    "optim": "adamw_torch",
    "lr_scheduler_type": "cosine",
    "fp16": not torch.cuda.is_bf16_supported(),
    "bf16": torch.cuda.is_bf16_supported(),
    "flash_attn": "auto",
    "output_dir": output_dir,
    "report_to": "none",
}

config_path = os.path.join(DRIVE_PATH, "train_config.yaml")
with open(config_path, "w", encoding="utf-8") as f:
    yaml.dump(config, f, allow_unicode=True, default_flow_style=False)
log(f"Training config saved to {config_path}")

# Copy config to LLaMA Factory
run_cmd(f"cp '{config_path}' /content/LLaMA-Factory/train_config.yaml")

# =============================================
# 5. START TRAINING
# =============================================
log("=" * 50)
log("=== 5. TRAINING STARTED ===")
log("=" * 50)

start_time = time.time()
log(f"Effective batch size: {config['per_device_train_batch_size'] * config['gradient_accumulation_steps']}")
log(f"Total epochs: {config['num_train_epochs']}")
log(f"Learning rate: {config['learning_rate']}")
log(f"LoRA rank: {config['lora_rank']}")
log(f"Quantization: {config['quantization_bit']}-bit")

result = run_cmd("cd /content/LLaMA-Factory && llamafactory-cli train train_config.yaml")

training_time = time.time() - start_time
log(f"Training completed in {training_time:.0f}s ({training_time/60:.1f} min)")

# =============================================
# 6. SAVE CHECKPOINT TO DRIVE
# =============================================
log("=== 6. SAVING CHECKPOINT TO DRIVE ===")

import glob
checkpoints = sorted(glob.glob(f"/content/LLaMA-Factory/{output_dir}/checkpoint-*"))
if checkpoints:
    latest = checkpoints[-1]
    log(f"Latest checkpoint: {latest}")

    final_adapter = os.path.join(DRIVE_PATH, f"{output_dir}_adapter")
    run_cmd(f"mkdir -p '{final_adapter}'")
    run_cmd(f"cp -r '{latest}/'* '{final_adapter}/'")
    log(f"LoRA adapter saved to: {final_adapter}/")

    # Also zip for easy download
    run_cmd(f"cd /content/LLaMA-Factory && zip -r '{DRIVE_PATH}/{output_dir}.zip' {output_dir}/")
    log(f"Full output zipped: {DRIVE_PATH}/{output_dir}.zip")
else:
    log("WARNING: No checkpoints found!")

# =============================================
# 7. SAVE TRAINING SUMMARY
# =============================================
log("=== 7. TRAINING SUMMARY ===")

summary = {
    "model": model_name,
    "output_dir": output_dir,
    "training_time_seconds": training_time,
    "training_time_minutes": round(training_time / 60, 1),
    "num_epochs": config["num_train_epochs"],
    "batch_size": config["per_device_train_batch_size"],
    "gradient_accumulation": config["gradient_accumulation_steps"],
    "learning_rate": config["learning_rate"],
    "lora_rank": config["lora_rank"],
    "quantization": f"{config['quantization_bit']}-bit",
    "samples": len(training_data),
    "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "None",
    "vram_gb": round(torch.cuda.get_device_properties(0).total_memory / 1e9, 1) if torch.cuda.is_available() else 0,
}

summary_path = os.path.join(DRIVE_PATH, "training_summary.json")
with open(summary_path, "w", encoding="utf-8") as f:
    json.dump(summary, f, ensure_ascii=False, indent=2)
log(f"Summary saved to {summary_path}")
log(f"Summary: {json.dumps(summary, ensure_ascii=False, indent=2)}")

log("=" * 50)
log("TRAINING COMPLETE - CHECK training_logs.txt FOR DETAILS")
log("=" * 50)
