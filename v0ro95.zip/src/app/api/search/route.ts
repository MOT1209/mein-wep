import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/search - البحث في المحتوى
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get('q')
    const type = searchParams.get('type') || 'all' // quran, hadith, azkar, names, all
    const limit = parseInt(searchParams.get('limit') || '10')
    
    if (!query || query.length < 2) {
      return NextResponse.json(
        { success: false, error: 'يجب إدخال كلمة بحث واحدة على الأقل' },
        { status: 400 }
      )
    }
    
    const results: {
      quran: unknown[]
      hadith: unknown[]
      azkar: unknown[]
      names: unknown[]
    } = {
      quran: [],
      hadith: [],
      azkar: [],
      names: []
    }
    
    // البحث في القرآن
    if (type === 'all' || type === 'quran') {
      results.quran = await db.quranVerse.findMany({
        where: {
          OR: [
            { text: { contains: query } },
            { textWithTashkeel: { contains: query } }
          ]
        },
        include: {
          surah: {
            select: { name: true, number: true }
          }
        },
        take: limit
      })
    }
    
    // البحث في الأحاديث
    if (type === 'all' || type === 'hadith') {
      results.hadith = await db.hadith.findMany({
        where: {
          OR: [
            { text: { contains: query } },
            { narrator: { contains: query } },
            { chapter: { contains: query } }
          ]
        },
        include: {
          collection: {
            select: { name: true }
          }
        },
        take: limit
      })
    }
    
    // البحث في الأذكار
    if (type === 'all' || type === 'azkar') {
      results.azkar = await db.zikr.findMany({
        where: {
          text: { contains: query }
        },
        include: {
          category: {
            select: { name: true }
          }
        },
        take: limit
      })
    }
    
    // البحث في أسماء الله الحسنى
    if (type === 'all' || type === 'names') {
      results.names = await db.allahName.findMany({
        where: {
          OR: [
            { name: { contains: query } },
            { meaning: { contains: query } },
            { description: { contains: query } }
          ]
        },
        take: limit
      })
    }
    
    const totalCount = 
      results.quran.length + 
      results.hadith.length + 
      results.azkar.length + 
      results.names.length
    
    return NextResponse.json({
      success: true,
      query,
      results,
      total: totalCount
    })
  } catch (error) {
    console.error('Error searching:', error)
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في البحث' },
      { status: 500 }
    )
  }
}
