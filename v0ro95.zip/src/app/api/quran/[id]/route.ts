import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/quran/[id] - جلب سورة معينة مع آياتها
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const surahId = parseInt(id)
    
    if (isNaN(surahId)) {
      return NextResponse.json(
        { success: false, error: 'رقم السورة غير صحيح' },
        { status: 400 }
      )
    }
    
    const surah = await db.quranSurah.findUnique({
      where: { number: surahId },
      include: {
        verses: {
          orderBy: { number: 'asc' }
        }
      }
    })
    
    if (!surah) {
      return NextResponse.json(
        { success: false, error: 'السورة غير موجودة' },
        { status: 404 }
      )
    }
    
    return NextResponse.json({
      success: true,
      data: surah
    })
  } catch (error) {
    console.error('Error fetching surah:', error)
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب السورة' },
      { status: 500 }
    )
  }
}
