import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/quran - جلب جميع السور
export async function GET() {
  try {
    const surahs = await db.quranSurah.findMany({
      orderBy: { number: 'asc' },
      include: {
        _count: {
          select: { verses: true }
        }
      }
    })
    
    return NextResponse.json({
      success: true,
      data: surahs
    })
  } catch (error) {
    console.error('Error fetching surahs:', error)
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب السور' },
      { status: 500 }
    )
  }
}
