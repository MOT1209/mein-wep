import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/hadith - جلب الأحاديث
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const collectionId = searchParams.get('collection')
    const limit = parseInt(searchParams.get('limit') || '20')
    const page = parseInt(searchParams.get('page') || '1')
    const skip = (page - 1) * limit
    
    const where = collectionId ? { collectionId: parseInt(collectionId) } : {}
    
    const [hadiths, total] = await Promise.all([
      db.hadith.findMany({
        where,
        include: {
          collection: true
        },
        orderBy: { id: 'asc' },
        take: limit,
        skip
      }),
      db.hadith.count({ where })
    ])
    
    return NextResponse.json({
      success: true,
      data: hadiths,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('Error fetching hadiths:', error)
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب الأحاديث' },
      { status: 500 }
    )
  }
}
