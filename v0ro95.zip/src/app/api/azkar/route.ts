import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/azkar - جلب الأذكار
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const categoryId = searchParams.get('category')
    
    if (categoryId) {
      // جلب أذكار قسم معين
      const azkar = await db.zikr.findMany({
        where: { categoryId: parseInt(categoryId) },
        orderBy: { id: 'asc' }
      })
      
      return NextResponse.json({
        success: true,
        data: azkar
      })
    }
    
    // جلب جميع الأقسام مع الأذكار
    const categories = await db.azkarCategory.findMany({
      orderBy: { order: 'asc' },
      include: {
        azkar: {
          orderBy: { id: 'asc' }
        }
      }
    })
    
    return NextResponse.json({
      success: true,
      data: categories
    })
  } catch (error) {
    console.error('Error fetching azkar:', error)
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب الأذكار' },
      { status: 500 }
    )
  }
}
