import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/names - جلب أسماء الله الحسنى
export async function GET() {
  try {
    const names = await db.allahName.findMany({
      orderBy: { id: 'asc' }
    })
    
    return NextResponse.json({
      success: true,
      data: names,
      count: names.length
    })
  } catch (error) {
    console.error('Error fetching Allah names:', error)
    return NextResponse.json(
      { success: false, error: 'حدث خطأ في جلب أسماء الله الحسنى' },
      { status: 500 }
    )
  }
}
