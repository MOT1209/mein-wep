import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

export const metadata: Metadata = {
  title: "نور الهدى - منصة إسلامية شاملة",
  description: "منصة إسلامية شاملة تضم القرآن الكريم، الأحاديث النبوية، الأذكار، أسماء الله الحسنى، والمزيد",
  keywords: ["قرآن", "حديث", "أذكار", "إسلام", "أسماء الله الحسنى", "تفسير"],
  authors: [{ name: "نور الهدى" }],
  icons: {
    icon: "/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body className="antialiased bg-gradient-to-b from-emerald-50 to-white dark:from-gray-900 dark:to-gray-800 text-gray-900 dark:text-gray-100">
        {children}
        <Toaster />
      </body>
    </html>
  );
}
