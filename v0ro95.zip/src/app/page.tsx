'use client'

import { useState, useEffect } from 'react'

// أنواع البيانات
interface Surah {
  id: number
  number: number
  name: string
  nameEn: string
  revelation: string
  versesCount: number
}

interface Hadith {
  id: number
  text: string
  narrator: string
  grade: string
  collection: { name: string }
}

interface Zikr {
  id: number
  text: string
  count: number
  reference: string
  time: string
  category: { name: string }
}

interface AllahName {
  id: number
  name: string
  meaning: string
}

interface SearchResult {
  quran: Array<{
    id: number
    text: string
    number: number
    surah: { name: string; number: number }
  }>
  hadith: Array<{
    id: number
    text: string
    narrator: string
    collection: { name: string }
  }>
  azkar: Array<{
    id: number
    text: string
    category: { name: string }
  }>
  names: Array<{
    id: number
    name: string
    meaning: string
  }>
}

type TabType = 'home' | 'quran' | 'hadith' | 'azkar' | 'names'

export default function Home() {
  const [activeTab, setActiveTab] = useState<TabType>('home')
  const [surahs, setSurahs] = useState<Surah[]>([])
  const [selectedSurah, setSelectedSurah] = useState<number | null>(null)
  const [surahVerses, setSurahVerses] = useState<{ surah: Surah; verses: Array<{ id: number; number: number; text: string }> } | null>(null)
  const [hadiths, setHadiths] = useState<Hadith[]>([])
  const [azkar, setAzkar] = useState<Array<{ id: number; name: string; azkar: Zikr[] }>>([])
  const [names, setNames] = useState<AllahName[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [searchResults, setSearchResults] = useState<SearchResult | null>(null)
  const [isSearching, setIsSearching] = useState(false)

  // جلب السور
  useEffect(() => {
    fetch('/api/quran')
      .then(res => res.json())
      .then(data => {
        if (data.success) setSurahs(data.data)
      })
  }, [])

  // جلب الأحاديث
  useEffect(() => {
    fetch('/api/hadith?limit=10')
      .then(res => res.json())
      .then(data => {
        if (data.success) setHadiths(data.data)
      })
  }, [])

  // جلب الأذكار
  useEffect(() => {
    fetch('/api/azkar')
      .then(res => res.json())
      .then(data => {
        if (data.success) setAzkar(data.data)
      })
  }, [])

  // جلب أسماء الله الحسنى
  useEffect(() => {
    fetch('/api/names')
      .then(res => res.json())
      .then(data => {
        if (data.success) setNames(data.data)
      })
  }, [])

  // البحث
  const handleSearch = async () => {
    if (!searchQuery.trim()) return
    setIsSearching(true)
    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(searchQuery)}`)
      const data = await res.json()
      if (data.success) {
        setSearchResults(data.results)
      }
    } finally {
      setIsSearching(false)
    }
  }

  // جلب آيات سورة
  const fetchSurahVerses = async (surahNumber: number) => {
    const res = await fetch(`/api/quran/${surahNumber}`)
    const data = await res.json()
    if (data.success) {
      setSurahVerses(data.data)
      setSelectedSurah(surahNumber)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 to-white">
      {/* الهيدر */}
      <header className="bg-emerald-700 text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          {/* العنوان والبحث */}
          <div className="flex items-center justify-between gap-4 mb-4 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center text-2xl">
                ☪
              </div>
              <div>
                <h1 className="text-2xl font-bold">نور الهدى</h1>
                <p className="text-emerald-100 text-sm">منصة إسلامية شاملة</p>
              </div>
            </div>
            
            {/* البحث */}
            <div className="flex-1 max-w-md">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="ابحث في القرآن والأحاديث..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                  className="flex-1 px-4 py-2 rounded-lg bg-white/20 border border-white/30 text-white placeholder-emerald-100 focus:outline-none focus:ring-2 focus:ring-white/50"
                />
                <button
                  onClick={handleSearch}
                  disabled={isSearching}
                  className="px-4 py-2 bg-white/20 hover:bg-white/30 rounded-lg transition disabled:opacity-50"
                >
                  {isSearching ? '...' : 'بحث'}
                </button>
              </div>
            </div>
          </div>
          
          {/* التنقل */}
          <nav className="flex gap-2 overflow-x-auto pb-2">
            {[
              { id: 'home', label: 'الرئيسية', icon: '🏠' },
              { id: 'quran', label: 'القرآن الكريم', icon: '📖' },
              { id: 'hadith', label: 'الأحاديث', icon: '📚' },
              { id: 'azkar', label: 'الأذكار', icon: '📿' },
              { id: 'names', label: 'أسماء الله الحسنى', icon: '✨' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`px-4 py-2 rounded-lg font-medium transition whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-white text-emerald-700'
                    : 'bg-white/10 hover:bg-white/20'
                }`}
              >
                {tab.icon} {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* المحتوى */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        
        {/* نتائج البحث */}
        {searchResults && (
          <section className="bg-white rounded-2xl shadow-lg p-6 mb-8">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-emerald-700">
                🔍 نتائج البحث عن: &quot;{searchQuery}&quot;
              </h2>
              <button 
                onClick={() => { setSearchResults(null); setSearchQuery('') }}
                className="text-gray-500 hover:text-gray-700"
              >
                ✕ إغلاق
              </button>
            </div>
            
            {/* آيات */}
            {searchResults.quran.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-bold text-emerald-600 mb-3">
                  📖 آيات قرآنية ({searchResults.quran.length})
                </h3>
                <div className="space-y-3">
                  {searchResults.quran.map((verse) => (
                    <div key={verse.id} className="bg-emerald-50 rounded-xl p-4 border-r-4 border-emerald-500">
                      <p className="text-lg leading-relaxed">{verse.text}</p>
                      <p className="text-sm text-emerald-600 mt-2">
                        سورة {verse.surah.name} - الآية {verse.number}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* أحاديث */}
            {searchResults.hadith.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-bold text-amber-600 mb-3">
                  📚 أحاديث ({searchResults.hadith.length})
                </h3>
                <div className="space-y-3">
                  {searchResults.hadith.map((hadith) => (
                    <div key={hadith.id} className="bg-amber-50 rounded-xl p-4 border-r-4 border-amber-500">
                      <p className="text-lg leading-relaxed">{hadith.text}</p>
                      <p className="text-sm text-amber-600 mt-2">
                        {hadith.collection.name} - {hadith.narrator}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* أذكار */}
            {searchResults.azkar.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-bold text-blue-600 mb-3">
                  📿 أذكار ({searchResults.azkar.length})
                </h3>
                <div className="space-y-3">
                  {searchResults.azkar.map((zikr) => (
                    <div key={zikr.id} className="bg-blue-50 rounded-xl p-4 border-r-4 border-blue-500">
                      <p className="text-lg leading-relaxed">{zikr.text}</p>
                      <p className="text-sm text-blue-600 mt-2">{zikr.category.name}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            {/* أسماء الله */}
            {searchResults.names.length > 0 && (
              <div>
                <h3 className="text-lg font-bold text-purple-600 mb-3">
                  ✨ أسماء الله الحسنى ({searchResults.names.length})
                </h3>
                <div className="flex flex-wrap gap-3">
                  {searchResults.names.map((name) => (
                    <div key={name.id} className="bg-purple-50 rounded-xl px-4 py-3 border border-purple-200">
                      <p className="text-xl font-bold text-purple-700">{name.name}</p>
                      <p className="text-sm text-purple-600">{name.meaning}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </section>
        )}

        {/* الصفحة الرئيسية */}
        {activeTab === 'home' && (
          <div className="space-y-8">
            {/* الترحيب */}
            <div className="text-center py-10 bg-gradient-to-l from-emerald-100 to-teal-100 rounded-3xl">
              <h2 className="text-3xl font-bold text-emerald-800 mb-4">
                بسم الله الرحمن الرحيم
              </h2>
              <p className="text-lg text-emerald-600 max-w-xl mx-auto">
                مرحباً بك في منصة نور الهدى، بوابتك الشاملة للمعرفة الإسلامية
              </p>
            </div>

            {/* بطاقات الأقسام */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div 
                onClick={() => setActiveTab('quran')}
                className="bg-white rounded-2xl shadow-lg p-6 text-center cursor-pointer hover:shadow-xl transition hover:-translate-y-1"
              >
                <div className="text-5xl mb-4">📖</div>
                <h3 className="text-xl font-bold text-emerald-700 mb-2">القرآن الكريم</h3>
                <p className="text-gray-500">{surahs.length} سورة</p>
              </div>
              
              <div 
                onClick={() => setActiveTab('hadith')}
                className="bg-white rounded-2xl shadow-lg p-6 text-center cursor-pointer hover:shadow-xl transition hover:-translate-y-1"
              >
                <div className="text-5xl mb-4">📚</div>
                <h3 className="text-xl font-bold text-emerald-700 mb-2">الأحاديث النبوية</h3>
                <p className="text-gray-500">{hadiths.length} حديث</p>
              </div>
              
              <div 
                onClick={() => setActiveTab('azkar')}
                className="bg-white rounded-2xl shadow-lg p-6 text-center cursor-pointer hover:shadow-xl transition hover:-translate-y-1"
              >
                <div className="text-5xl mb-4">📿</div>
                <h3 className="text-xl font-bold text-emerald-700 mb-2">الأذكار</h3>
                <p className="text-gray-500">{azkar.reduce((acc, cat) => acc + cat.azkar.length, 0)} ذكر</p>
              </div>
              
              <div 
                onClick={() => setActiveTab('names')}
                className="bg-white rounded-2xl shadow-lg p-6 text-center cursor-pointer hover:shadow-xl transition hover:-translate-y-1"
              >
                <div className="text-5xl mb-4">✨</div>
                <h3 className="text-xl font-bold text-emerald-700 mb-2">أسماء الله الحسنى</h3>
                <p className="text-gray-500">{names.length} اسم</p>
              </div>
            </div>

            {/* حديث اليوم */}
            {hadiths.length > 0 && (
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <h3 className="text-xl font-bold text-emerald-700 mb-4">💫 حديث اليوم</h3>
                <div className="bg-amber-50 rounded-xl p-6">
                  <p className="text-xl leading-relaxed">{hadiths[0]?.text}</p>
                  <p className="text-amber-700 mt-4">{hadiths[0]?.narrator} - {hadiths[0]?.collection?.name}</p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* قسم القرآن */}
        {activeTab === 'quran' && (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-emerald-700">📖 القرآن الكريم</h2>
            
            {selectedSurah && surahVerses ? (
              <div>
                <button 
                  onClick={() => { setSelectedSurah(null); setSurahVerses(null) }}
                  className="mb-6 px-4 py-2 bg-emerald-100 text-emerald-700 rounded-lg hover:bg-emerald-200 transition"
                >
                  ← العودة للسور
                </button>
                
                <div className="bg-white rounded-2xl shadow-lg p-6">
                  <div className="text-center mb-6">
                    <h3 className="text-3xl font-bold text-emerald-700">
                      سورة {surahVerses.surah.name}
                    </h3>
                    <p className="text-gray-500 mt-2">
                      {surahVerses.surah.revelation} - {surahVerses.surah.versesCount} آية
                    </p>
                  </div>
                  
                  <div className="bg-emerald-50 rounded-2xl p-6 leading-loose text-2xl text-right" dir="rtl">
                    {surahVerses.verses.map((verse) => (
                      <span key={verse.id} className="inline">
                        <span>{verse.text} </span>
                        <span className="inline-flex items-center justify-center w-8 h-8 mx-1 text-sm font-bold text-emerald-700 bg-emerald-200 rounded-full">
                          {verse.number}
                        </span>
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {surahs.map((surah) => (
                  <div
                    key={surah.id}
                    onClick={() => fetchSurahVerses(surah.number)}
                    className="bg-white rounded-xl shadow p-4 cursor-pointer hover:shadow-lg transition hover:-translate-y-1"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center text-emerald-700 font-bold">
                        {surah.number}
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-emerald-700">{surah.name}</h3>
                        <p className="text-xs text-gray-500">
                          {surah.versesCount} آية • {surah.revelation}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* قسم الأحاديث */}
        {activeTab === 'hadith' && (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-emerald-700">📚 الأحاديث النبوية</h2>
            
            <div className="grid gap-4">
              {hadiths.map((hadith) => (
                <div key={hadith.id} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition">
                  <p className="text-xl leading-relaxed mb-4">{hadith.text}</p>
                  <div className="flex flex-wrap items-center gap-3 text-sm">
                    <span className="bg-amber-100 text-amber-700 px-3 py-1 rounded-full">
                      {hadith.collection.name}
                    </span>
                    <span className="text-gray-500">{hadith.narrator}</span>
                    <span className={`px-3 py-1 rounded-full ${
                      hadith.grade === 'صحيح' 
                        ? 'bg-green-100 text-green-700'
                        : 'bg-blue-100 text-blue-700'
                    }`}>
                      {hadith.grade}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* قسم الأذكار */}
        {activeTab === 'azkar' && (
          <div className="space-y-8">
            <h2 className="text-3xl font-bold text-emerald-700">📿 الأذكار والأدعية</h2>
            
            {azkar.map((category) => (
              <div key={category.id} className="space-y-4">
                <h3 className="text-2xl font-bold text-emerald-600 flex items-center gap-2">
                  <span className="w-2 h-6 bg-emerald-500 rounded-full"></span>
                  {category.name}
                </h3>
                
                <div className="grid gap-4">
                  {category.azkar.map((zikr) => (
                    <div key={zikr.id} className="bg-white rounded-xl shadow p-5 hover:shadow-lg transition">
                      <p className="text-xl leading-relaxed mb-3">{zikr.text}</p>
                      <div className="flex flex-wrap items-center justify-between gap-3 text-sm">
                        <div className="flex items-center gap-3">
                          <span className="bg-emerald-100 text-emerald-700 px-4 py-1 rounded-full font-bold">
                            التكرار: {zikr.count}
                          </span>
                          <span className="text-gray-500">{zikr.reference}</span>
                        </div>
                        {zikr.time && (
                          <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full">
                            {zikr.time}
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* قسم أسماء الله الحسنى */}
        {activeTab === 'names' && (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-emerald-700">✨ أسماء الله الحسنى</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {names.map((name) => (
                <div
                  key={name.id}
                  className="bg-white rounded-xl shadow p-5 text-center hover:shadow-xl transition hover:-translate-y-1 cursor-pointer"
                >
                  <div className="text-2xl font-bold text-emerald-700 mb-2">{name.name}</div>
                  <p className="text-gray-600 text-sm">{name.meaning}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* الفوتر */}
      <footer className="bg-gray-900 text-white py-10 mt-10">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h3 className="text-2xl font-bold mb-2">نور الهدى</h3>
          <p className="text-gray-400 mb-6">منصة إسلامية شاملة للقرآن والأحاديث والأذكار</p>
          <div className="flex justify-center gap-6 text-gray-400 text-sm">
            <span>📖 القرآن الكريم</span>
            <span>📚 الأحاديث</span>
            <span>📿 الأذكار</span>
            <span>✨ أسماء الله الحسنى</span>
          </div>
          <div className="mt-6 pt-6 border-t border-gray-800 text-gray-500 text-sm">
            جميع الحقوق محفوظة © {new Date().getFullYear()} نور الهدى
          </div>
        </div>
      </footer>
    </div>
  )
}
