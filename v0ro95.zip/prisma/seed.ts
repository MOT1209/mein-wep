import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

// بيانات السور القرآنية
const surahsData = [
  { number: 1, name: "الفاتحة", nameEn: "Al-Fatihah", englishName: "The Opening", revelation: "مكية", versesCount: 7, order: 5 },
  { number: 2, name: "البقرة", nameEn: "Al-Baqarah", englishName: "The Cow", revelation: "مدنية", versesCount: 286, order: 87 },
  { number: 3, name: "آل عمران", nameEn: "Aal-Imran", englishName: "The Family of Imran", revelation: "مدنية", versesCount: 200, order: 89 },
  { number: 4, name: "النساء", nameEn: "An-Nisa", englishName: "The Women", revelation: "مدنية", versesCount: 176, order: 92 },
  { number: 5, name: "المائدة", nameEn: "Al-Ma'idah", englishName: "The Table", revelation: "مدنية", versesCount: 120, order: 112 },
  { number: 6, name: "الأنعام", nameEn: "Al-An'am", englishName: "The Cattle", revelation: "مكية", versesCount: 165, order: 55 },
  { number: 7, name: "الأعراف", nameEn: "Al-A'raf", englishName: "The Heights", revelation: "مكية", versesCount: 206, order: 39 },
  { number: 8, name: "الأنفال", nameEn: "Al-Anfal", englishName: "The Spoils of War", revelation: "مدنية", versesCount: 75, order: 88 },
  { number: 9, name: "التوبة", nameEn: "At-Tawbah", englishName: "The Repentance", revelation: "مدنية", versesCount: 129, order: 113 },
  { number: 10, name: "يونس", nameEn: "Yunus", englishName: "Jonah", revelation: "مكية", versesCount: 109, order: 51 },
  { number: 11, name: "هود", nameEn: "Hud", englishName: "Hud", revelation: "مكية", versesCount: 123, order: 52 },
  { number: 12, name: "يوسف", nameEn: "Yusuf", englishName: "Joseph", revelation: "مكية", versesCount: 111, order: 53 },
  { number: 13, name: "الرعد", nameEn: "Ar-Ra'd", englishName: "The Thunder", revelation: "مدنية", versesCount: 43, order: 96 },
  { number: 14, name: "إبراهيم", nameEn: "Ibrahim", englishName: "Abraham", revelation: "مكية", versesCount: 52, order: 72 },
  { number: 15, name: "الحجر", nameEn: "Al-Hijr", englishName: "The Rocky Tract", revelation: "مكية", versesCount: 99, order: 54 },
  { number: 16, name: "النحل", nameEn: "An-Nahl", englishName: "The Bee", revelation: "مكية", versesCount: 128, order: 70 },
  { number: 17, name: "الإسراء", nameEn: "Al-Isra", englishName: "The Night Journey", revelation: "مكية", versesCount: 111, order: 50 },
  { number: 18, name: "الكهف", nameEn: "Al-Kahf", englishName: "The Cave", revelation: "مكية", versesCount: 110, order: 69 },
  { number: 19, name: "مريم", nameEn: "Maryam", englishName: "Mary", revelation: "مكية", versesCount: 98, order: 44 },
  { number: 20, name: "طه", nameEn: "Ta-Ha", englishName: "Ta-Ha", revelation: "مكية", versesCount: 135, order: 45 },
  { number: 21, name: "الأنبياء", nameEn: "Al-Anbiya", englishName: "The Prophets", revelation: "مكية", versesCount: 112, order: 73 },
  { number: 22, name: "الحج", nameEn: "Al-Hajj", englishName: "The Pilgrimage", revelation: "مدنية", versesCount: 78, order: 103 },
  { number: 23, name: "المؤمنون", nameEn: "Al-Mu'minun", englishName: "The Believers", revelation: "مكية", versesCount: 118, order: 74 },
  { number: 24, name: "النور", nameEn: "An-Nur", englishName: "The Light", revelation: "مدنية", versesCount: 64, order: 102 },
  { number: 25, name: "الفرقان", nameEn: "Al-Furqan", englishName: "The Criterion", revelation: "مكية", versesCount: 77, order: 42 },
  { number: 26, name: "الشعراء", nameEn: "Ash-Shu'ara", englishName: "The Poets", revelation: "مكية", versesCount: 227, order: 47 },
  { number: 27, name: "النمل", nameEn: "An-Naml", englishName: "The Ant", revelation: "مكية", versesCount: 93, order: 48 },
  { number: 28, name: "القصص", nameEn: "Al-Qasas", englishName: "The Stories", revelation: "مكية", versesCount: 88, order: 49 },
  { number: 29, name: "العنكبوت", nameEn: "Al-Ankabut", englishName: "The Spider", revelation: "مكية", versesCount: 69, order: 85 },
  { number: 30, name: "الروم", nameEn: "Ar-Rum", englishName: "The Romans", revelation: "مكية", versesCount: 60, order: 84 },
  { number: 31, name: "لقمان", nameEn: "Luqman", englishName: "Luqman", revelation: "مكية", versesCount: 34, order: 57 },
  { number: 32, name: "السجدة", nameEn: "As-Sajdah", englishName: "The Prostration", revelation: "مكية", versesCount: 30, order: 75 },
  { number: 33, name: "الأحزاب", nameEn: "Al-Ahzab", englishName: "The Combined Forces", revelation: "مدنية", versesCount: 73, order: 90 },
  { number: 34, name: "سبأ", nameEn: "Saba", englishName: "Sheba", revelation: "مكية", versesCount: 54, order: 58 },
  { number: 35, name: "فاطر", nameEn: "Fatir", englishName: "Originator", revelation: "مكية", versesCount: 45, order: 43 },
  { number: 36, name: "يس", nameEn: "Ya-Sin", englishName: "Ya Sin", revelation: "مكية", versesCount: 83, order: 41 },
  { number: 37, name: "الصافات", nameEn: "As-Saffat", englishName: "Those Who Set The Ranks", revelation: "مكية", versesCount: 182, order: 56 },
  { number: 38, name: "ص", nameEn: "Sad", englishName: "The Letter Sad", revelation: "مكية", versesCount: 88, order: 38 },
  { number: 39, name: "الزمر", nameEn: "Az-Zumar", englishName: "The Troops", revelation: "مكية", versesCount: 75, order: 59 },
  { number: 40, name: "غافر", nameEn: "Ghafir", englishName: "The Forgiver", revelation: "مكية", versesCount: 85, order: 60 },
  { number: 41, name: "فصلت", nameEn: "Fussilat", englishName: "Explained in Detail", revelation: "مكية", versesCount: 54, order: 61 },
  { number: 42, name: "الشورى", nameEn: "Ash-Shura", englishName: "The Consultation", revelation: "مكية", versesCount: 53, order: 62 },
  { number: 43, name: "الزخرف", nameEn: "Az-Zukhruf", englishName: "The Ornaments of Gold", revelation: "مكية", versesCount: 89, order: 63 },
  { number: 44, name: "الدخان", nameEn: "Ad-Dukhan", englishName: "The Smoke", revelation: "مكية", versesCount: 59, order: 64 },
  { number: 45, name: "الجاثية", nameEn: "Al-Jathiyah", englishName: "The Crouching", revelation: "مكية", versesCount: 37, order: 65 },
  { number: 46, name: "الأحقاف", nameEn: "Al-Ahqaf", englishName: "The Wind-Curved Sandhills", revelation: "مكية", versesCount: 35, order: 66 },
  { number: 47, name: "محمد", nameEn: "Muhammad", englishName: "Muhammad", revelation: "مدنية", versesCount: 38, order: 95 },
  { number: 48, name: "الفتح", nameEn: "Al-Fath", englishName: "The Victory", revelation: "مدنية", versesCount: 29, order: 111 },
  { number: 49, name: "الحجرات", nameEn: "Al-Hujurat", englishName: "The Rooms", revelation: "مدنية", versesCount: 18, order: 106 },
  { number: 50, name: "ق", nameEn: "Qaf", englishName: "The Letter Qaf", revelation: "مكية", versesCount: 45, order: 34 },
  { number: 51, name: "الذاريات", nameEn: "Adh-Dhariyat", englishName: "The Winnowing Winds", revelation: "مكية", versesCount: 60, order: 67 },
  { number: 52, name: "الطور", nameEn: "At-Tur", englishName: "The Mount", revelation: "مكية", versesCount: 49, order: 76 },
  { number: 53, name: "النجم", nameEn: "An-Najm", englishName: "The Star", revelation: "مكية", versesCount: 62, order: 23 },
  { number: 54, name: "القمر", nameEn: "Al-Qamar", englishName: "The Moon", revelation: "مكية", versesCount: 55, order: 37 },
  { number: 55, name: "الرحمن", nameEn: "Ar-Rahman", englishName: "The Beneficent", revelation: "مدنية", versesCount: 78, order: 97 },
  { number: 56, name: "الواقعة", nameEn: "Al-Waqi'ah", englishName: "The Inevitable", revelation: "مكية", versesCount: 96, order: 46 },
  { number: 57, name: "الحديد", nameEn: "Al-Hadid", englishName: "The Iron", revelation: "مدنية", versesCount: 29, order: 94 },
  { number: 58, name: "المجادلة", nameEn: "Al-Mujadila", englishName: "The Pleading Woman", revelation: "مدنية", versesCount: 22, order: 105 },
  { number: 59, name: "الحشر", nameEn: "Al-Hashr", englishName: "The Exile", revelation: "مدنية", versesCount: 24, order: 101 },
  { number: 60, name: "الممتحنة", nameEn: "Al-Mumtahanah", englishName: "She that is to be examined", revelation: "مدنية", versesCount: 13, order: 91 },
  { number: 61, name: "الصف", nameEn: "As-Saff", englishName: "The Ranks", revelation: "مدنية", versesCount: 14, order: 109 },
  { number: 62, name: "الجمعة", nameEn: "Al-Jumu'ah", englishName: "The Congregation", revelation: "مدنية", versesCount: 11, order: 110 },
  { number: 63, name: "المنافقون", nameEn: "Al-Munafiqun", englishName: "The Hypocrites", revelation: "مدنية", versesCount: 11, order: 104 },
  { number: 64, name: "التغابن", nameEn: "At-Taghabun", englishName: "The Mutual Disillusion", revelation: "مدنية", versesCount: 18, order: 108 },
  { number: 65, name: "الطلاق", nameEn: "At-Talaq", englishName: "The Divorce", revelation: "مدنية", versesCount: 12, order: 99 },
  { number: 66, name: "التحريم", nameEn: "At-Tahrim", englishName: "The Prohibition", revelation: "مدنية", versesCount: 12, order: 107 },
  { number: 67, name: "الملك", nameEn: "Al-Mulk", englishName: "The Sovereignty", revelation: "مكية", versesCount: 30, order: 77 },
  { number: 68, name: "القلم", nameEn: "Al-Qalam", englishName: "The Pen", revelation: "مكية", versesCount: 52, order: 2 },
  { number: 69, name: "الحاقة", nameEn: "Al-Haqqah", englishName: "The Reality", revelation: "مكية", versesCount: 52, order: 78 },
  { number: 70, name: "المعارج", nameEn: "Al-Ma'arij", englishName: "The Ascending Stairways", revelation: "مكية", versesCount: 44, order: 79 },
  { number: 71, name: "نوح", nameEn: "Nuh", englishName: "Noah", revelation: "مكية", versesCount: 28, order: 71 },
  { number: 72, name: "الجن", nameEn: "Al-Jinn", englishName: "The Jinn", revelation: "مكية", versesCount: 28, order: 40 },
  { number: 73, name: "المزمل", nameEn: "Al-Muzzammil", englishName: "The Enshrouded One", revelation: "مكية", versesCount: 20, order: 3 },
  { number: 74, name: "المدثر", nameEn: "Al-Muddaththir", englishName: "The Cloaked One", revelation: "مكية", versesCount: 56, order: 4 },
  { number: 75, name: "القيامة", nameEn: "Al-Qiyamah", englishName: "The Resurrection", revelation: "مكية", versesCount: 40, order: 31 },
  { number: 76, name: "الإنسان", nameEn: "Al-Insan", englishName: "The Human", revelation: "مدنية", versesCount: 31, order: 98 },
  { number: 77, name: "المرسلات", nameEn: "Al-Mursalat", englishName: "The Emissaries", revelation: "مكية", versesCount: 50, order: 33 },
  { number: 78, name: "النبأ", nameEn: "An-Naba", englishName: "The Tidings", revelation: "مكية", versesCount: 40, order: 80 },
  { number: 79, name: "النازعات", nameEn: "An-Nazi'at", englishName: "Those who drag forth", revelation: "مكية", versesCount: 46, order: 81 },
  { number: 80, name: "عبس", nameEn: "Abasa", englishName: "He Frowned", revelation: "مكية", versesCount: 42, order: 24 },
  { number: 81, name: "التكوير", nameEn: "At-Takwir", englishName: "The Overthrowing", revelation: "مكية", versesCount: 29, order: 7 },
  { number: 82, name: "الانفطار", nameEn: "Al-Infitar", englishName: "The Cleaving", revelation: "مكية", versesCount: 19, order: 82 },
  { number: 83, name: "المطففين", nameEn: "Al-Mutaffifin", englishName: "The Defrauding", revelation: "مكية", versesCount: 36, order: 86 },
  { number: 84, name: "الانشقاق", nameEn: "Al-Inshiqaq", englishName: "The Sundering", revelation: "مكية", versesCount: 25, order: 83 },
  { number: 85, name: "البروج", nameEn: "Al-Buruj", englishName: "The Mansions of the Stars", revelation: "مكية", versesCount: 22, order: 27 },
  { number: 86, name: "الطارق", nameEn: "At-Tariq", englishName: "The Nightcomer", revelation: "مكية", versesCount: 17, order: 36 },
  { number: 87, name: "الأعلى", nameEn: "Al-A'la", englishName: "The Most High", revelation: "مكية", versesCount: 19, order: 8 },
  { number: 88, name: "الغاشية", nameEn: "Al-Ghashiyah", englishName: "The Overwhelming", revelation: "مكية", versesCount: 26, order: 68 },
  { number: 89, name: "الفجر", nameEn: "Al-Fajr", englishName: "The Dawn", revelation: "مكية", versesCount: 30, order: 10 },
  { number: 90, name: "البلد", nameEn: "Al-Balad", englishName: "The City", revelation: "مكية", versesCount: 20, order: 35 },
  { number: 91, name: "الشمس", nameEn: "Ash-Shams", englishName: "The Sun", revelation: "مكية", versesCount: 15, order: 26 },
  { number: 92, name: "الليل", nameEn: "Al-Layl", englishName: "The Night", revelation: "مكية", versesCount: 21, order: 9 },
  { number: 93, name: "الضحى", nameEn: "Ad-Duhaa", englishName: "The Morning Hours", revelation: "مكية", versesCount: 11, order: 11 },
  { number: 94, name: "الشرح", nameEn: "Ash-Sharh", englishName: "The Relief", revelation: "مكية", versesCount: 8, order: 12 },
  { number: 95, name: "التين", nameEn: "At-Tin", englishName: "The Fig", revelation: "مكية", versesCount: 8, order: 28 },
  { number: 96, name: "العلق", nameEn: "Al-Alaq", englishName: "The Clot", revelation: "مكية", versesCount: 19, order: 1 },
  { number: 97, name: "القدر", nameEn: "Al-Qadr", englishName: "The Power", revelation: "مكية", versesCount: 5, order: 25 },
  { number: 98, name: "البينة", nameEn: "Al-Bayyinah", englishName: "The Clear Proof", revelation: "مدنية", versesCount: 8, order: 100 },
  { number: 99, name: "الزلزلة", nameEn: "Az-Zalzalah", englishName: "The Earthquake", revelation: "مدنية", versesCount: 8, order: 93 },
  { number: 100, name: "العاديات", nameEn: "Al-Adiyat", englishName: "The Courser", revelation: "مكية", versesCount: 11, order: 14 },
  { number: 101, name: "القارعة", nameEn: "Al-Qari'ah", englishName: "The Calamity", revelation: "مكية", versesCount: 11, order: 30 },
  { number: 102, name: "التكاثر", nameEn: "At-Takathur", englishName: "The Rivalry in world", revelation: "مكية", versesCount: 8, order: 16 },
  { number: 103, name: "العصر", nameEn: "Al-Asr", englishName: "The Declining Day", revelation: "مكية", versesCount: 3, order: 13 },
  { number: 104, name: "الهمزة", nameEn: "Al-Humazah", englishName: "The Traducer", revelation: "مكية", versesCount: 9, order: 32 },
  { number: 105, name: "الفيل", nameEn: "Al-Fil", englishName: "The Elephant", revelation: "مكية", versesCount: 5, order: 19 },
  { number: 106, name: "قريش", nameEn: "Quraysh", englishName: "Quraysh", revelation: "مكية", versesCount: 4, order: 29 },
  { number: 107, name: "الماعون", nameEn: "Al-Ma'un", englishName: "The Small Kindnesses", revelation: "مكية", versesCount: 7, order: 17 },
  { number: 108, name: "الكوثر", nameEn: "Al-Kawthar", englishName: "The Abundance", revelation: "مكية", versesCount: 3, order: 15 },
  { number: 109, name: "الكافرون", nameEn: "Al-Kafirun", englishName: "The Disbelievers", revelation: "مكية", versesCount: 6, order: 18 },
  { number: 110, name: "النصر", nameEn: "An-Nasr", englishName: "The Divine Support", revelation: "مدنية", versesCount: 3, order: 114 },
  { number: 111, name: "المسد", nameEn: "Al-Masad", englishName: "The Palm Fiber", revelation: "مكية", versesCount: 5, order: 6 },
  { number: 112, name: "الإخلاص", nameEn: "Al-Ikhlas", englishName: "The Sincerity", revelation: "مكية", versesCount: 4, order: 22 },
  { number: 113, name: "الفلق", nameEn: "Al-Falaq", englishName: "The Daybreak", revelation: "مكية", versesCount: 5, order: 20 },
  { number: 114, name: "الناس", nameEn: "An-Nas", englishName: "Mankind", revelation: "مكية", versesCount: 6, order: 21 },
]

// آيات سورة الفاتحة
const fatihahVerses = [
  { number: 1, text: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", juz: 1, hizb: 1, page: 1 },
  { number: 2, text: "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", juz: 1, hizb: 1, page: 1 },
  { number: 3, text: "الرَّحْمَٰنِ الرَّحِيمِ", juz: 1, hizb: 1, page: 1 },
  { number: 4, text: "مَالِكِ يَوْمِ الدِّينِ", juz: 1, hizb: 1, page: 1 },
  { number: 5, text: "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ", juz: 1, hizb: 1, page: 1 },
  { number: 6, text: "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ", juz: 1, hizb: 1, page: 1 },
  { number: 7, text: "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ", juz: 1, hizb: 1, page: 1 },
]

// آيات سورة الإخلاص
const ikhlasVerses = [
  { number: 1, text: "قُلْ هُوَ اللَّهُ أَحَدٌ", juz: 30, hizb: 60, page: 604 },
  { number: 2, text: "اللَّهُ الصَّمَدُ", juz: 30, hizb: 60, page: 604 },
  { number: 3, text: "لَمْ يَلِدْ وَلَمْ يُولَدْ", juz: 30, hizb: 60, page: 604 },
  { number: 4, text: "وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ", juz: 30, hizb: 60, page: 604 },
]

// آيات سورة الفلق
const falaqVerses = [
  { number: 1, text: "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ", juz: 30, hizb: 60, page: 604 },
  { number: 2, text: "مِن شَرِّ مَا خَلَقَ", juz: 30, hizb: 60, page: 604 },
  { number: 3, text: "وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ", juz: 30, hizb: 60, page: 604 },
  { number: 4, text: "وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ", juz: 30, hizb: 60, page: 604 },
  { number: 5, text: "وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ", juz: 30, hizb: 60, page: 604 },
]

// آيات سورة الناس
const nasVerses = [
  { number: 1, text: "قُلْ أَعُوذُ بِرَبِّ النَّاسِ", juz: 30, hizb: 60, page: 604 },
  { number: 2, text: "مَلِكِ النَّاسِ", juz: 30, hizb: 60, page: 604 },
  { number: 3, text: "إِلَٰهِ النَّاسِ", juz: 30, hizb: 60, page: 604 },
  { number: 4, text: "مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ", juz: 30, hizb: 60, page: 604 },
  { number: 5, text: "الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ", juz: 30, hizb: 60, page: 604 },
  { number: 6, text: "مِنَ الْجِنَّةِ وَالنَّاسِ", juz: 30, hizb: 60, page: 604 },
]

// أسماء الله الحسنى
const allahNames = [
  { name: "الله", nameEn: "Allah", meaning: "الاسم الأعظم، العلم على الذات الواجب الوجود", description: "هو الاسم الجامع لجميع صفات الكمال والجلال" },
  { name: "الرحمن", nameEn: "Ar-Rahman", meaning: "ذي الرحمة الواسعة الشاملة لجميع الخلق", description: "رحمان الدنيا والآخرة ورحيمهما" },
  { name: "الرحيم", nameEn: "Ar-Rahim", meaning: "المتفضل بالإنعام والإحسان", description: "ذي الرحمة الواصلة للمؤمنين يوم القيامة" },
  { name: "الملك", nameEn: "Al-Malik", meaning: "المتصرف بجميع الموجودات", description: "مالك الملك والملكوت، بيده مقاليد الأمور" },
  { name: "القدوس", nameEn: "Al-Quddus", meaning: "المنزه عن كل نقص", description: "الطاهر من كل عيب، المبرأ من كل نقص" },
  { name: "السلام", nameEn: "As-Salam", meaning: "السلام من جميع العيوب والنقائص", description: "ذي السلامة والسلام والبراءة من كل نقص" },
  { name: "المؤمن", nameEn: "Al-Mu'min", meaning: "المصدق نفسه بكماله", description: "المؤمن الذي يؤمن أولياءه من عذابه" },
  { name: "المهيمن", nameEn: "Al-Muhaymin", meaning: "المسيطر على كل شيء", description: "الرقيب الحافظ لكل شيء" },
  { name: "العزيز", nameEn: "Al-Aziz", meaning: "الذي لا يغالب ولا يُقهر", description: "ذي العزة والغلبة والقوة" },
  { name: "الجبار", nameEn: "Al-Jabbar", meaning: "الذي يجبر الكسير ويقهر العدو", description: "الذي تنفذ مشيئته ولا تناله المجبرة" },
  { name: "المتكبر", nameEn: "Al-Mutakabbir", meaning: "المتكبر عن السوء والنقص", description: "ذي الكبرياء والعظمة" },
  { name: "الخالق", nameEn: "Al-Khaliq", meaning: "المبدع لكل شيء من العدم", description: "الذي أوجد كل شيء بتقدير" },
  { name: "البارئ", nameEn: "Al-Bari", meaning: "الخالق للأشياء على غير مثال", description: "الذي خلق الخلق بقدرته" },
  { name: "المصور", nameEn: "Al-Musawwir", meaning: "الذي يعطي كل شيء صورته", description: "مصور الأشكال والصور" },
  { name: "الغفار", nameEn: "Al-Ghaffar", meaning: "الذي يستر ذنوب عباده", description: "كثير المغفرة والستر على عباده" },
  { name: "القهار", nameEn: "Al-Qahhar", meaning: "القاهر لكل شيء", description: "الذي قهر كل شيء وخضع له كل شيء" },
  { name: "الوهاب", nameEn: "Al-Wahhab", meaning: "كثير النعم والعطايا", description: "الذي يهب العطايا بلا مقابل" },
  { name: "الرزاق", nameEn: "Ar-Razzaq", meaning: "المتفضل بالأرزاق على الخلق", description: "خالق الأرزاق ومقدرها وموصلها للخلق" },
  { name: "الفتاح", nameEn: "Al-Fattah", meaning: "الذي يفتح أبواب الرزق والرحمة", description: "الحاكم بين عباده بالقسط" },
  { name: "العليم", nameEn: "Al-Alim", meaning: "المحيط بكل المعلومات", description: "العالم بظواهر الأمور وبواطنها" },
]

// أذكار الصباح والمساء
const azkarData = [
  { category: "أذكار الصباح", azkar: [
    { text: "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ", count: 1, reference: "صحيح مسلم", time: "صباح" },
    { text: "اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ", count: 1, reference: "سنن الترمذي", time: "صباح" },
    { text: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَٰهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَىٰ عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ", count: 1, reference: "صحيح البخاري", time: "صباح", reward: "سيد الاستغفار" },
    { text: "اللَّهُمَّ إِنِّي أَصْبَحْتُ أُشْهِدُكَ، وَأُشْهِدُ حَمَلَةَ عَرْشِكَ، وَمَلَائِكَتَكَ، وَجَمِيعَ خَلْقِكَ، أَنَّكَ أَنْتَ اللَّهُ لَا إِلَٰهَ إِلَّا أَنْتَ وَحْدَكَ لَا شَرِيكَ لَكَ، وَأَنَّ مُحَمَّدًا عَبْدُكَ وَرَسُولُكَ", count: 4, reference: "سنن أبي داود", time: "صباح", reward: "من قالها أعتقه الله من النار" },
    { text: "اللَّهُمَّ مَا أَصْبَحَ بِي مِنْ نِعْمَةٍ أَوْ بِأَحَدٍ مِنْ خَلْقِكَ فَمِنْكَ وَحْدَكَ لَا شَرِيكَ لَكَ، فَلَكَ الْحَمْدُ وَلَكَ الشُّكْرُ", count: 1, reference: "سنن أبي داود", time: "صباح", reward: "من قالها حين يصبح فقد أدى شكر يومه" },
    { text: "اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لَا إِلَٰهَ إِلَّا أَنْتَ. اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْكُفْرِ، وَالْفَقْرِ، وَأَعُوذُ بِكَ مِنْ عَذَابِ الْقَبْرِ، لَا إِلَٰهَ إِلَّا أَنْتَ", count: 3, reference: "سنن أبي داود", time: "صباح" },
    { text: "حَسْبِيَ اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ", count: 7, reference: "سنن أبي داود", time: "صباح", reward: "من قالها سبع مرات كفاه الله ما أهمه" },
    { text: "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ", count: 3, reference: "سنن الترمذي", time: "صباح", reward: "من قالها لم تصبه فجأة بلاء حتى يمسي" },
    { text: "رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا", count: 3, reference: "سنن الترمذي", time: "صباح", reward: "من قالها ثلاثاً حين يصبح وحين يمسي كان حقاً على الله أن يرضيه يوم القيامة" },
    { text: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", count: 100, reference: "صحيح مسلم", time: "صباح", reward: "من قالها مائة مرة حين يصبح وحين يمسي لم يأتِ أحد يوم القيامة بأفضل مما جاء به إلا أحد قال مثل ما قال أو زاد عليه" },
  ]},
  { category: "أذكار المساء", azkar: [
    { text: "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ", count: 1, reference: "صحيح مسلم", time: "مساء" },
    { text: "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ", count: 1, reference: "سنن الترمذي", time: "مساء" },
    { text: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَٰهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَىٰ عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ", count: 1, reference: "صحيح البخاري", time: "مساء", reward: "سيد الاستغفار" },
    { text: "اللَّهُمَّ إِنِّي أَمْسَيْتُ أُشْهِدُكَ، وَأُشْهِدُ حَمَلَةَ عَرْشِكَ، وَمَلَائِكَتَكَ، وَجَمِيعَ خَلْقِكَ، أَنَّكَ أَنْتَ اللَّهُ لَا إِلَٰهَ إِلَّا أَنْتَ وَحْدَكَ لَا شَرِيكَ لَكَ، وَأَنَّ مُحَمَّدًا عَبْدُكَ وَرَسُولُكَ", count: 4, reference: "سنن أبي داود", time: "مساء", reward: "من قالها أعتقه الله من النار" },
    { text: "اللَّهُمَّ مَا أَمْسَى بِي مِنْ نِعْمَةٍ أَوْ بِأَحَدٍ مِنْ خَلْقِكَ فَمِنْكَ وَحْدَكَ لَا شَرِيكَ لَكَ، فَلَكَ الْحَمْدُ وَلَكَ الشُّكْرُ", count: 1, reference: "سنن أبي داود", time: "مساء", reward: "من قالها حين يمسي فقد أدى شكر ليلته" },
    { text: "اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لَا إِلَٰهَ إِلَّا أَنْتَ. اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْكُفْرِ، وَالْفَقْرِ، وَأَعُوذُ بِكَ مِنْ عَذَابِ الْقَبْرِ، لَا إِلَٰهَ إِلَّا أَنْتَ", count: 3, reference: "سنن أبي داود", time: "مساء" },
    { text: "حَسْبِيَ اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ", count: 7, reference: "سنن أبي داود", time: "مساء", reward: "من قالها سبع مرات كفاه الله ما أهمه" },
    { text: "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ", count: 3, reference: "صحيح مسلم", time: "مساء", reward: "من قالها حين يمسي ثلاث مرات لم تضره حُمة تلك الليلة" },
    { text: "اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَالْآخِرَةِ، اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي دِينِي وَدُنْيَايَ وَأَهْلِي وَمَالِي", count: 1, reference: "سنن ابن ماجه", time: "مساء" },
    { text: "اللَّهُمَّ اسْتُرْ عَوْرَاتِي، وَآمِنْ رَوْعَاتِي، اللَّهُمَّ احْفَظْنِي مِنْ بَيْنِ يَدَيَّ، وَمِنْ خَلْفِي، وَعَنْ يَمِينِي، وَعَنْ شِمَالِي، وَمِنْ فَوْقِي، وَأَعُوذُ بِعَظَمَتِكَ أَنْ أُغْتَالَ مِنْ تَحْتِي", count: 1, reference: "سنن أبي داود", time: "مساء" },
  ]},
  { category: "أذكار بعد الصلاة", azkar: [
    { text: "أَسْتَغْفِرُ اللَّهَ", count: 3, reference: "صحيح البخاري", time: "بعد الصلاة" },
    { text: "اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ", count: 1, reference: "صحيح مسلم", time: "بعد الصلاة" },
    { text: "لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ، اللَّهُمَّ لَا مَانِعَ لِمَا أَعْطَيْتَ، وَلَا مُعْطِيَ لِمَا مَنَعْتَ، وَلَا يَنْفَعُ ذَا الْجَدِّ مِنْكَ الْجَدُّ", count: 1, reference: "متفق عليه", time: "بعد الصلاة" },
    { text: "لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ، لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ، لَا إِلَٰهَ إِلَّا اللَّهُ، وَلَا نَعْبُدُ إِلَّا إِيَّاهُ، لَهُ النِّعْمَةُ وَلَهُ الْفَضْلُ وَلَهُ الثَّنَاءُ الْحَسَنُ، لَا إِلَٰهَ إِلَّا اللَّهُ مُخْلِصِينَ لَهُ الدِّينَ وَلَوْ كَرِهَ الْكَافِرُونَ", count: 1, reference: "صحيح مسلم", time: "بعد الصلاة" },
    { text: "سُبْحَانَ اللَّهِ", count: 33, reference: "صحيح مسلم", time: "بعد الصلاة" },
    { text: "الْحَمْدُ لِلَّهِ", count: 33, reference: "صحيح مسلم", time: "بعد الصلاة" },
    { text: "اللَّهُ أَكْبَرُ", count: 33, reference: "صحيح مسلم", time: "بعد الصلاة" },
    { text: "لَا إِلَٰهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَىٰ كُلِّ شَيْءٍ قَدِيرٌ", count: 1, reference: "صحيح مسلم", time: "بعد الصلاة", reward: "من قالها غفرت له ذنوبه وإن كانت مثل زبد البحر" },
  ]},
]

// أحاديث مختارة
const hadithsData = [
  {
    collection: "صحيح البخاري",
    collectionEn: "Sahih Bukhari",
    author: "الإمام البخاري",
    hadiths: [
      { number: "1", text: "إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى، فَمَنْ كَانَتْ هِجْرَتُهُ إِلَى دُنْيَا يُصِيبُهَا أَوْ إِلَى امْرَأَةٍ يَنْكِحُهَا فَهِجْرَتُهُ إِلَى مَا هَاجَرَ إِلَيْهِ", narrator: "عمر بن الخطاب رضي الله عنه", grade: "صحيح", chapter: "بدء الوحي" },
      { number: "2", text: "مَنْ رَأَى مِنْكُمْ مُنْكَرًا فَلْيُغَيِّرْهُ بِيَدِهِ، فَإِنْ لَمْ يَسْتَطِعْ فَبِلِسَانِهِ، فَإِنْ لَمْ يَسْتَطِعْ فَبِقَلْبِهِ، وَذَلِكَ أَضْعَفُ الإِيمَانِ", narrator: "أبو سعيد الخدري رضي الله عنه", grade: "صحيح", chapter: "الإيمان" },
      { number: "3", text: "مَنْ كَانَ يُؤْمِنُ بِاللَّهِ وَالْيَوْمِ الآخِرِ فَلْيَقُلْ خَيْرًا أَوْ لِيَصْمُتْ، وَمَنْ كَانَ يُؤْمِنُ بِاللَّهِ وَالْيَوْمِ الآخِرِ فَلْيُكْرِمْ جَارَهُ، وَمَنْ كَانَ يُؤْمِنُ بِاللَّهِ وَالْيَوْمِ الآخِرِ فَلْيُكْرِمْ ضَيْفَهُ", narrator: "أبي هريرة رضي الله عنه", grade: "صحيح", chapter: "الإيمان" },
      { number: "4", text: "لاَ يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ", narrator: "أنس بن مالك رضي الله عنه", grade: "صحيح", chapter: "الإيمان" },
      { number: "5", text: "الْمُسْلِمُ مَنْ سَلِمَ الْمُسْلِمُونَ مِنْ لِسَانِهِ وَيَدِهِ", narrator: "عبدالله بن عمرو رضي الله عنهما", grade: "صحيح", chapter: "الإيمان" },
    ]
  },
  {
    collection: "صحيح مسلم",
    collectionEn: "Sahih Muslim",
    author: "الإمام مسلم",
    hadiths: [
      { number: "1", text: "بُنِيَ الإِسْلاَمُ عَلَى خَمْسٍ: شَهَادَةِ أَنْ لاَ إِلَهَ إِلاَّ اللَّهُ وَأَنَّ مُحَمَّدًا رَسُولُ اللَّهِ، وَإِقَامِ الصَّلاَةِ، وَإِيتَاءِ الزَّكَاةِ، وَالْحَجِّ، وَصَوْمِ رَمَضَانَ", narrator: "عبدالله بن عمر رضي الله عنهما", grade: "صحيح", chapter: "الإيمان" },
      { number: "2", text: "مَنْ سَلَكَ طَرِيقًا يَلْتَمِسُ فِيهِ عِلْمًا سَهَّلَ اللَّهُ لَهُ بِهِ طَرِيقًا إِلَى الْجَنَّةِ", narrator: "أبي هريرة رضي الله عنه", grade: "صحيح", chapter: "العلم" },
      { number: "3", text: "الطُّهُورُ شَطْرُ الإِيمَانِ، وَالْحَمْدُ لِلَّهِ تَمْلأُ الْمِيزَانَ، وَسُبْحَانَ اللَّهِ وَالْحَمْدُ لِلَّهِ تَمْلأَانِ مَا بَيْنَ السَّمَاوَاتِ وَالأَرْضِ", narrator: "أبي مالك الأشعري رضي الله عنه", grade: "صحيح", chapter: "الطهارة" },
      { number: "4", text: "إِنَّ اللَّهَ لاَ يَنْظُرُ إِلَى صُوَرِكُمْ وَأَمْوَالِكُمْ، وَلَكِنْ يَنْظُرُ إِلَى قُلُوبِكُمْ وَأَعْمَالِكُمْ", narrator: "أبي هريرة رضي الله عنه", grade: "صحيح", chapter: "البر والصلة" },
      { number: "5", text: "الدُّنْيَا سِجْنُ الْمُؤْمِنِ وَجَنَّةُ الْكَافِرِ", narrator: "أبي هريرة رضي الله عنه", grade: "صحيح", chapter: "الزهد والرقائق" },
    ]
  },
  {
    collection: "الأربعون النووية",
    collectionEn: "An-Nawawi's Forty Hadith",
    author: "الإمام النووي",
    hadiths: [
      { number: "1", text: "إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى", narrator: "عمر بن الخطاب رضي الله عنه", grade: "صحيح", chapter: "النية" },
      { number: "2", text: "قَالَ رَسُولُ اللَّهِ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ: بُنِيَ الإِسْلاَمُ عَلَى خَمْسٍ", narrator: "عبدالله بن عمر رضي الله عنهما", grade: "صحيح", chapter: "أركان الإسلام" },
      { number: "6", text: "الْحَلاَلُ بَيِّنٌ وَالْحَرَامُ بَيِّنٌ، وَبَيْنَهُمَا أُمُورٌ مُشْتَبِهَاتٌ لاَ يَعْلَمُهُنَّ كَثِيرٌ مِنَ النَّاسِ", narrator: "النعمان بن بشير رضي الله عنه", grade: "صحيح", chapter: "الحلال والحرام" },
      { number: "7", text: "دِينُ النَّصِيحَةِ. قُلْنَا: لِمَنْ؟ قَالَ: لِلَّهِ وَلِكِتَابِهِ وَلِرَسُولِهِ وَلأَئِمَّةِ الْمُسْلِمِينَ وَعَامَّتِهِمْ", narrator: "تميم الداري رضي الله عنه", grade: "صحيح", chapter: "النصيحة" },
      { number: "13", text: "لاَ يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ", narrator: "أنس بن مالك رضي الله عنه", grade: "صحيح", chapter: "الإيمان" },
      { number: "24", text: "قَالَ اللَّهُ تَعَالَى: أَنَا عِنْدَ ظَنِّ عَبْدِي بِي، وَأَنَا مَعَهُ إِذَا ذَكَرَنِي", narrator: "أبي هريرة رضي الله عنه", grade: "صحيح", chapter: "حديث قدسي" },
    ]
  },
]

async function main() {
  console.log("🌱 بدء إدخال البيانات...")

  // 1. إدخال السور
  console.log("📖 إدخال السور القرآنية...")
  for (const surah of surahsData) {
    await prisma.quranSurah.create({
      data: surah
    })
  }
  console.log(`✅ تم إدخال ${surahsData.length} سورة`)

  // 2. إدخال آيات سورة الفاتحة
  console.log("📖 إدخال آيات سورة الفاتحة...")
  let globalNumber = 1
  for (const verse of fatihahVerses) {
    await prisma.quranVerse.create({
      data: {
        surahId: 1,
        number: verse.number,
        globalNumber: globalNumber++,
        text: verse.text,
        textWithTashkeel: verse.text,
        juz: verse.juz,
        hizb: verse.hizb,
        page: verse.page,
      }
    })
  }
  console.log(`✅ تم إدخال ${fatihahVerses.length} آية من سورة الفاتحة`)

  // 3. إدخال آيات سورة الإخلاص
  console.log("📖 إدخال آيات سورة الإخلاص...")
  globalNumber = 6222
  for (const verse of ikhlasVerses) {
    await prisma.quranVerse.create({
      data: {
        surahId: 112,
        number: verse.number,
        globalNumber: globalNumber++,
        text: verse.text,
        textWithTashkeel: verse.text,
        juz: verse.juz,
        hizb: verse.hizb,
        page: verse.page,
      }
    })
  }
  console.log(`✅ تم إدخال ${ikhlasVerses.length} آية من سورة الإخلاص`)

  // 4. إدخال آيات سورة الفلق
  console.log("📖 إدخال آيات سورة الفلق...")
  globalNumber = 6226
  for (const verse of falaqVerses) {
    await prisma.quranVerse.create({
      data: {
        surahId: 113,
        number: verse.number,
        globalNumber: globalNumber++,
        text: verse.text,
        textWithTashkeel: verse.text,
        juz: verse.juz,
        hizb: verse.hizb,
        page: verse.page,
      }
    })
  }
  console.log(`✅ تم إدخال ${falaqVerses.length} آية من سورة الفلق`)

  // 5. إدخال آيات سورة الناس
  console.log("📖 إدخال آيات سورة الناس...")
  globalNumber = 6231
  for (const verse of nasVerses) {
    await prisma.quranVerse.create({
      data: {
        surahId: 114,
        number: verse.number,
        globalNumber: globalNumber++,
        text: verse.text,
        textWithTashkeel: verse.text,
        juz: verse.juz,
        hizb: verse.hizb,
        page: verse.page,
      }
    })
  }
  console.log(`✅ تم إدخال ${nasVerses.length} آية من سورة الناس`)

  // 6. إدخال أسماء الله الحسنى
  console.log("✨ إدخال أسماء الله الحسنى...")
  for (const name of allahNames) {
    await prisma.allahName.create({
      data: name
    })
  }
  console.log(`✅ تم إدخال ${allahNames.length} اسم من أسماء الله الحسنى`)

  // 7. إدخال الأذكار
  console.log("📿 إدخال الأذكار...")
  for (const categoryData of azkarData) {
    const category = await prisma.azkarCategory.create({
      data: {
        name: categoryData.category,
        nameEn: categoryData.category === "أذكار الصباح" ? "Morning Azkar" : 
                categoryData.category === "أذكار المساء" ? "Evening Azkar" : "After Prayer Azkar",
      }
    })
    
    for (const zikr of categoryData.azkar) {
      await prisma.zikr.create({
        data: {
          categoryId: category.id,
          text: zikr.text,
          textWithoutHarakat: zikr.text.replace(/[\u064B-\u065F]/g, ''),
          count: zikr.count,
          reference: zikr.reference,
          reward: zikr.reward || null,
          time: zikr.time,
        }
      })
    }
  }
  console.log(`✅ تم إدخال أذكار ${azkarData.length} أقسام`)

  // 8. إدخال كتب الحديث والأحاديث
  console.log("📚 إدخال كتب الحديث والأحاديث...")
  for (const collectionData of hadithsData) {
    const collection = await prisma.hadithCollection.create({
      data: {
        name: collectionData.collection,
        nameEn: collectionData.collectionEn,
        author: collectionData.author,
      }
    })
    
    for (const hadith of collectionData.hadiths) {
      await prisma.hadith.create({
        data: {
          collectionId: collection.id,
          number: hadith.number,
          text: hadith.text,
          textWithoutHarakat: hadith.text.replace(/[\u064B-\u065F]/g, ''),
          narrator: hadith.narrator,
          grade: hadith.grade,
          gradeEn: hadith.grade === "صحيح" ? "Sahih (Authentic)" : "Hasan (Good)",
          chapter: hadith.chapter,
        }
      })
    }
  }
  console.log(`✅ تم إدخال ${hadithsData.length} كتب حديث`)

  console.log("🎉 تم إدخال جميع البيانات بنجاح!")
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
